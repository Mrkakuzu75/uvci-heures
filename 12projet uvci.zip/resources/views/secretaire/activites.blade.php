@extends('layouts.app')
@section('title','Activités')
@section('sidebar-role','Secrétaire Principal')
@section('page-title','Activités pédagogiques')

@section('sidebar-nav')
  <x-nav-item route="secretaire.dashboard"   label="Tableau de bord"   icon="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/>
  <x-nav-item route="secretaire.enseignants" label="Enseignants"        icon="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"/>
  <x-nav-item route="secretaire.cours"       label="Cours"              icon="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"/>
  <x-nav-item route="secretaire.activites"   label="Activités"          icon="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/>
  <x-nav-item route="secretaire.paiements"   label="États de paiement"  icon="M9 14l6-6m-5.5.5h.01m4.99 5h.01M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16l3.5-2 3.5 2 3.5-2 3.5 2z"/>
@endsection

@section('topbar-actions')
  <a href="{{ route('secretaire.activites.create') }}" class="btn btn-navy">
    <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
      <path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4"/>
    </svg>
    <span class="btn-text">Nouvelle activité</span>
  </a>
@endsection

@section('content')

{{-- Résumé --}}
<div class="flex items-center justify-between flex-wrap gap-3 mb-5">
  <div>
    <span class="text-[15px] font-semibold text-navy">Suivi des activités</span>
    <span class="text-[13px] text-[#6B7A8D] ml-2">— {{ $annee?->lib_anee ?? 'Toutes les années' }}</span>
  </div>
  <div class="bg-green-light border border-green/30 rounded-xl px-4 py-2">
    <span class="text-[12px] text-green-dark font-medium">Volume total : </span>
    <span class="text-[15px] font-bold text-green-dark">{{ number_format($activites->sum('v_hor'),1) }}h</span>
  </div>
</div>

<div class="card">
  <div class="card-header">
    <h3>{{ $activites->total() }} activité(s)</h3>
    <a href="{{ route('secretaire.activites.create') }}" class="btn btn-green btn-sm">+ Nouvelle</a>
  </div>
  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>Date</th>
          <th>Enseignant</th>
          <th class="hide-mobile">Cours / Ressource</th>
          <th class="hide-mobile">Type</th>
          <th>Vol. (h)</th>
          <th>Statut</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        @forelse($activites as $act)
        <tr>
          <td class="text-[#6B7A8D] whitespace-nowrap text-[13px]">{{ $act->date_act->format('d/m/Y') }}</td>
          <td class="font-medium text-[13.5px]">{{ $act->enseignant?->nom_complet ?? '—' }}</td>
          <td class="hide-mobile">
            <div class="text-[13px] font-medium max-w-[200px] truncate">
              {{ $act->ressource?->sequence?->cours?->intit ?? '—' }}
            </div>
            <div class="text-[11px] text-[#6B7A8D]">Niveau {{ $act->ressource?->niv_comp ?? '?' }}</div>
          </td>
          <td class="hide-mobile">
            @if($act->id_typ_act == 1)
              <span class="badge-green">Création</span>
            @else
              <span class="badge-orange">Mise à jour</span>
            @endif
          </td>
          <td class="font-bold text-[14px] text-green whitespace-nowrap">{{ number_format($act->v_hor,2) }}h</td>

          {{-- Statut --}}
          <td>
            @if($act->est_valide)
              <span class="badge-green">Validée</span>
              @if($act->date_validation)
              <div class="text-[10px] text-[#6B7A8D] mt-0.5">le {{ $act->date_validation->format('d/m/Y') }}</div>
              @endif
            @else
              <span class="inline-block px-2.5 py-1 rounded-full text-[11px] font-semibold
                           bg-red-50 border border-red-200 text-red-600">
                En attente
              </span>
            @endif
          </td>

          {{-- Action valider --}}
          <td>
            @if(!$act->est_valide)
              <form method="POST" action="{{ route('secretaire.activites.valider', $act) }}">
                @csrf @method('PATCH')
                <button type="submit" class="btn btn-green btn-sm">
                  <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" class="w-3 h-3">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/>
                  </svg>
                  Valider
                </button>
              </form>
            @else
              <span class="text-[#6B7A8D] text-[12px]">—</span>
            @endif
          </td>
        </tr>
        @empty
        <tr>
          <td colspan="7" class="text-center py-10 text-[#6B7A8D]">Aucune activité enregistrée</td>
        </tr>
        @endforelse
      </tbody>
    </table>
  </div>
  @if($activites->hasPages())
  <div class="px-5 py-3.5 border-t border-[#E2E8F0]">{{ $activites->links() }}</div>
  @endif
</div>
@endsection