@extends('layouts.app')
@section('title','Enseignants')
@section('sidebar-role','Secrétaire Principal')
@section('page-title','Enseignants')
@section('page-subtitle','Liste et gestion des enseignants')

@section('sidebar-nav')
  <x-nav-item route="secretaire.dashboard"   label="Tableau de bord"   icon="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/>
  <x-nav-item route="secretaire.enseignants" label="Enseignants"        icon="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"/>
  <x-nav-item route="secretaire.cours"       label="Cours"              icon="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"/>
  <x-nav-item route="secretaire.activites"   label="Activités"          icon="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/>
  <x-nav-item route="secretaire.paiements"   label="États de paiement"  icon="M9 14l6-6m-5.5.5h.01m4.99 5h.01M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16l3.5-2 3.5 2 3.5-2 3.5 2z"/>
@endsection

@section('topbar-actions')
  <a href="{{ route('secretaire.enseignants.export-excel') }}" class="btn btn-outline" title="Exporter la liste en Excel">
    <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
      <path stroke-linecap="round" stroke-linejoin="round"
        d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586
           a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
    </svg>
    <span class="btn-text">Exporter Excel</span>
  </a>
  <a href="{{ route('secretaire.enseignants.create') }}" class="btn btn-navy">
    <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
      <path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4"/>
    </svg>
    <span class="btn-text">Ajouter</span>
  </a>
@endsection

@section('content')
<div class="card">
  <div class="card-header">
    <h3>{{ $enseignants->total() }} enseignant(s)</h3>
  </div>

  {{-- Filtres --}}
  <div class="px-5 py-3 border-b border-[#E2E8F0] flex gap-2.5 flex-wrap">
    <div class="relative flex-1 min-w-[160px]">
      <svg class="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-[#6B7A8D] pointer-events-none"
           fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
        <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
      </svg>
      <input type="text" id="search" oninput="filterTable()" placeholder="Rechercher un enseignant…"
             class="w-full pl-8 pr-3 py-2 border-[1.5px] border-[#E2E8F0] rounded-lg text-[13px]
                    bg-[#FAFAFA] text-navy outline-none font-[inherit]
                    focus:border-green transition-colors">
    </div>
    <select id="filterSt" onchange="filterTable()"
            class="px-3 py-2 border-[1.5px] border-[#E2E8F0] rounded-lg text-[13px]
                   bg-[#FAFAFA] text-navy outline-none cursor-pointer font-[inherit]
                   focus:border-green transition-colors">
      <option value="">Tous les statuts</option>
      <option value="permanent">Permanent</option>
      <option value="vacataire">Vacataire</option>
    </select>
  </div>

  <div class="table-wrap">
    <table id="tbl">
      <thead>
        <tr>
          <th>Enseignant</th>
          <th>Grade</th>
          <th class="hide-mobile">Statut</th>
          <th class="hide-mobile">Département</th>
          <th>Volume (h)</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        @php $avc=['av-green','av-blue','av-purple','av-orange','av-teal']; @endphp
        @forelse($enseignants as $ens)
        <tr data-statut="{{ strtolower($ens->statut?->lib_stat ?? '') }}"
            data-nom="{{ strtolower($ens->nom_complet) }}">
          <td>
            <div class="flex items-center gap-2.5">
              <div class="avatar {{ $avc[$loop->index % 5] }}">{{ $ens->initiales }}</div>
              <div>
                <div class="font-medium text-[13.5px]">{{ $ens->nom_complet }}</div>
                <div class="text-[11px] text-[#6B7A8D]">{{ $ens->utilisateur?->email ?? 'Pas de compte' }}</div>
              </div>
            </div>
          </td>
          <td><span class="badge-green">{{ $ens->grade?->lib_grd ?? '—' }}</span></td>
          <td class="hide-mobile">
            @if(strtolower($ens->statut?->lib_stat ?? '') === 'permanent')
              <span class="badge-blue">Permanent</span>
            @else
              <span class="badge-orange">Vacataire</span>
            @endif
          </td>
          <td class="hide-mobile text-[13px] text-[#6B7A8D]">{{ $ens->departement?->lib_dep ?? '—' }}</td>
          <td class="font-bold text-[14px]">{{ number_format($ens->volume_horaire ?? 0, 1) }}h</td>
          <td>
            <div class="flex gap-1.5">
              <a href="{{ route('secretaire.enseignants.edit',$ens) }}" class="btn btn-outline btn-sm">Modifier</a>
              <form method="POST" action="{{ route('secretaire.enseignants.destroy',$ens) }}"
                    onsubmit="return confirm('Supprimer cet enseignant ?')">
                @csrf @method('DELETE')
                <button type="submit" class="btn btn-danger btn-sm">Suppr.</button>
              </form>
            </div>
          </td>
        </tr>
        @empty
        <tr>
          <td colspan="6" class="text-center py-10 text-[#6B7A8D]">Aucun enseignant enregistré</td>
        </tr>
        @endforelse
      </tbody>
    </table>
  </div>

  @if($enseignants->hasPages())
  <div class="px-5 py-3.5 border-t border-[#E2E8F0]">{{ $enseignants->links() }}</div>
  @endif
</div>

@push('scripts')
<script>
function filterTable(){
  var s  = document.getElementById('search').value.toLowerCase();
  var st = document.getElementById('filterSt').value.toLowerCase();
  document.querySelectorAll('#tbl tbody tr[data-nom]').forEach(function(r){
    r.style.display = (!s || r.dataset.nom.includes(s)) && (!st || r.dataset.statut.includes(st)) ? '' : 'none';
  });
}
</script>
@endpush
@endsection