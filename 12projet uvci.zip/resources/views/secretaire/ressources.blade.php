@extends('layouts.app')
@section('title','Ressources')
@section('sidebar-role','Secrétaire Principal')
@section('page-title','Ressources pédagogiques')
@section('page-subtitle', $sequence->ttre_seq)

@section('sidebar-nav')
  <x-nav-item route="secretaire.dashboard"   label="Tableau de bord"   icon="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/>
  <x-nav-item route="secretaire.enseignants" label="Enseignants"        icon="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"/>
  <x-nav-item route="secretaire.cours"       label="Cours"              icon="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"/>
  <x-nav-item route="secretaire.activites"   label="Activités"          icon="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/>
  <x-nav-item route="secretaire.paiements"   label="États de paiement"  icon="M9 14l6-6m-5.5.5h.01m4.99 5h.01M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16l3.5-2 3.5 2 3.5-2 3.5 2z"/>
@endsection

@section('topbar-actions')
  <a href="{{ route('secretaire.sequences', $sequence->cours) }}" class="btn btn-outline">
    ← Retour aux séquences
  </a>
@endsection

@section('content')
<div class="flex flex-col gap-5">

  {{-- Fil d'Ariane --}}
  <div class="flex items-center gap-2 text-[12px] text-[#6B7A8D] flex-wrap">
    <a href="{{ route('secretaire.cours') }}" class="text-green-dark no-underline hover:underline">Cours</a>
    <span>›</span>
    <a href="{{ route('secretaire.sequences',$sequence->cours) }}" class="text-green-dark no-underline hover:underline">
      {{ $sequence->cours?->intit }}
    </a>
    <span>›</span>
    <span class="text-navy font-medium">{{ $sequence->ttre_seq }}</span>
  </div>

  {{-- Info niveaux --}}
  <div class="grid gap-3" style="grid-template-columns:repeat(auto-fit,minmax(200px,1fr))">
    @foreach([
      1=>['label'=>'Niveau 1','desc'=>'Contenus simples + quiz + évaluations','color'=>'#4A90E2'],
      2=>['label'=>'Niveau 2','desc'=>'Niv.1 + activités interactives','color'=>'#00C07F'],
      3=>['label'=>'Niveau 3','desc'=>'Serious games, simulations','color'=>'#9B59B6'],
    ] as $niv=>$info)
    <div class="border border-[#E2E8F0] rounded-xl px-3.5 py-3"
         style="border-left:4px solid {{ $info['color'] }}">
      <div class="font-semibold text-[13px]" style="color:{{ $info['color'] }}">{{ $info['label'] }}</div>
      <div class="text-[11px] text-[#6B7A8D] mt-0.5">{{ $info['desc'] }}</div>
    </div>
    @endforeach
  </div>

  {{-- Liste des ressources --}}
  <div class="card">
    <div class="card-header">
      <h3>Ressources ({{ $ressources->count() }})</h3>
    </div>
    @php $nivColors=[1=>'#4A90E2',2=>'#00C07F',3=>'#9B59B6']; @endphp
    @forelse($ressources as $ress)
    <div class="flex items-center gap-3.5 px-5 py-3 border-t border-[#F0F2F5]">
      <div class="w-8 h-8 rounded-lg flex items-center justify-center font-bold text-[13px] shrink-0 border"
           style="background:{{ ($nivColors[$ress->niv_comp]??'#ccc') }}22;
                  color:{{ $nivColors[$ress->niv_comp]??'#ccc' }};
                  border-color:{{ ($nivColors[$ress->niv_comp]??'#ccc') }}44;">
        N{{ $ress->niv_comp }}
      </div>
      <div class="flex-1 min-w-0">
        <div class="font-medium text-[13px]">{{ $ress->typeRessource?->lib_typ_ress }}</div>
        <div class="text-[11px] text-[#6B7A8D] mt-0.5">
          Créée le {{ $ress->dte_creat_ress?->format('d/m/Y') }}
          {{ $ress->dte_maj_ress ? ' · Mise à jour : '.$ress->dte_maj_ress->format('d/m/Y') : '' }}
        </div>
      </div>
      <form method="POST" action="{{ route('secretaire.ressources.destroy', $ress) }}"
            onsubmit="return confirm('Supprimer cette ressource ?')">
        @csrf @method('DELETE')
        <button type="submit" class="btn btn-danger btn-sm">Supprimer</button>
      </form>
    </div>
    @empty
    <div class="py-8 text-center text-[13px] text-[#6B7A8D]">
      Aucune ressource — ajoutez-en ci-dessous
    </div>
    @endforelse
  </div>

  {{-- Formulaire ajout ressource --}}
  <div class="card">
    <div class="card-header"><h3>Ajouter une ressource</h3></div>
    <form method="POST" action="{{ route('secretaire.ressources.store', $sequence) }}"
          class="card-body flex flex-col gap-3.5">
      @csrf
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-3.5">
        <div>
          <label class="form-label">Niveau de complexité <span class="text-red-500">*</span></label>
          <select name="niv_comp" class="form-input" required>
            <option value="">Choisir…</option>
            <option value="1" {{ old('niv_comp')==1?'selected':'' }}>Niveau 1 — Simple</option>
            <option value="2" {{ old('niv_comp')==2?'selected':'' }}>Niveau 2 — Interactif</option>
            <option value="3" {{ old('niv_comp')==3?'selected':'' }}>Niveau 3 — Serious game</option>
          </select>
          @error('niv_comp')<div class="form-error">{{ $message }}</div>@enderror
        </div>
        <div>
          <label class="form-label">Type de ressource <span class="text-red-500">*</span></label>
          <select name="id_typ_ress" class="form-input" required>
            <option value="">Choisir…</option>
            @foreach($typesRessources as $tr)
            <option value="{{ $tr->id_typ_ress }}" {{ old('id_typ_ress')==$tr->id_typ_ress?'selected':'' }}>
              {{ $tr->lib_typ_ress }}
            </option>
            @endforeach
          </select>
          @error('id_typ_ress')<div class="form-error">{{ $message }}</div>@enderror
        </div>
        <div>
          <label class="form-label">Date de création <span class="text-red-500">*</span></label>
          <input type="date" name="dte_creat_ress"
                 value="{{ old('dte_creat_ress', date('Y-m-d')) }}"
                 class="form-input" required>
        </div>
      </div>
      <div class="flex justify-end">
        <button type="submit" class="btn btn-navy">Ajouter la ressource</button>
      </div>
    </form>
  </div>

</div>
@endsection