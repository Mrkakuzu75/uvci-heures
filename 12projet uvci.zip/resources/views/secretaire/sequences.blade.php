@extends('layouts.app')
@section('title','Séquences')
@section('sidebar-role','Secrétaire Principal')
@section('page-title','Séquences du cours')
@section('page-subtitle', $cours->intit . ' — ' . $cours->niv)

@section('sidebar-nav')
  <x-nav-item route="secretaire.dashboard"   label="Tableau de bord"   icon="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/>
  <x-nav-item route="secretaire.enseignants" label="Enseignants"        icon="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"/>
  <x-nav-item route="secretaire.cours"       label="Cours"              icon="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"/>
  <x-nav-item route="secretaire.activites"   label="Activités"          icon="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/>
  <x-nav-item route="secretaire.paiements"   label="États de paiement"  icon="M9 14l6-6m-5.5.5h.01m4.99 5h.01M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16l3.5-2 3.5 2 3.5-2 3.5 2z"/>
@endsection

@section('topbar-actions')
  <a href="{{ route('secretaire.cours') }}" class="btn btn-outline">
    ← Retour aux cours
  </a>
@endsection

@section('content')
<div class="flex flex-col gap-5">

  {{-- Bandeau info cours --}}
  <div class="bg-navy rounded-xl px-5 py-4 flex items-center gap-4 flex-wrap">
    <div class="w-10 h-10 bg-green rounded-[10px] flex items-center justify-center
                font-bold text-[14px] text-navy shrink-0">
      {{ $cours->niv }}
    </div>
    <div class="flex-1 min-w-0">
      <div class="font-bold text-[15px] text-white">{{ $cours->intit }}</div>
      <div class="text-[12px] text-white/50 mt-0.5">
        {{ $cours->filre }} — {{ $cours->semestre?->lib_sem }} —
        {{ $cours->nbr_crdt }} crédits — {{ $cours->nbr_squce }} séquences prévues
      </div>
    </div>
    <div class="text-right shrink-0">
      <div class="font-bold text-[22px] text-green">{{ $sequences->count() }}/{{ $cours->nbr_squce }}</div>
      <div class="text-[11px] text-white/40">séquences créées</div>
    </div>
  </div>

  {{-- Liste des séquences --}}
  <div class="card">
    <div class="card-header">
      <h3>Séquences ({{ $sequences->count() }})</h3>
    </div>
    @forelse($sequences as $seq)
    <div class="flex items-center gap-3.5 px-5 py-3.5 border-t border-[#F0F2F5]">
      <div class="w-8 h-8 rounded-lg bg-green-light flex items-center justify-center
                  font-bold text-[13px] text-green-dark shrink-0">
        {{ $seq->ordre }}
      </div>
      <div class="flex-1 min-w-0">
        <div class="font-medium text-[13.5px]">{{ $seq->ttre_seq }}</div>
        @if($seq->desc_seq)
        <div class="text-[11px] text-[#6B7A8D] mt-0.5">{{ $seq->desc_seq }}</div>
        @endif
      </div>
      <div class="flex items-center gap-2 shrink-0">
        <a href="{{ route('secretaire.ressources', $seq) }}" class="btn btn-green btn-sm">
          {{ $seq->ressources_count }} ressource(s) →
        </a>
        <form method="POST" action="{{ route('secretaire.sequences.destroy', $seq) }}"
              onsubmit="return confirm('Supprimer cette séquence et ses ressources ?')">
          @csrf @method('DELETE')
          <button type="submit" class="btn btn-danger btn-sm">×</button>
        </form>
      </div>
    </div>
    @empty
    <div class="py-8 text-center text-[13px] text-[#6B7A8D]">
      Aucune séquence — ajoutez-en ci-dessous
    </div>
    @endforelse
  </div>

  {{-- Formulaire ajout séquence --}}
  <div class="card">
    <div class="card-header"><h3>Ajouter une séquence</h3></div>
    <form method="POST" action="{{ route('secretaire.sequences.store', $cours) }}"
          class="card-body flex flex-col gap-3.5">
      @csrf
      <div>
        <label class="form-label">Titre de la séquence <span class="text-red-500">*</span></label>
        <input type="text" name="ttre_seq" value="{{ old('ttre_seq') }}"
               class="form-input" placeholder="ex: Introduction aux variables" required>
        @error('ttre_seq')<div class="form-error">{{ $message }}</div>@enderror
      </div>
      <div>
        <label class="form-label">Description</label>
        <textarea name="desc_seq" class="form-input resize-y" rows="2"
                  placeholder="Description optionnelle…">{{ old('desc_seq') }}</textarea>
      </div>
      <div class="flex justify-end">
        <button type="submit" class="btn btn-navy">Ajouter la séquence</button>
      </div>
    </form>
  </div>

</div>
@endsection