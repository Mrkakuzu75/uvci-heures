<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="csrf-token" content="{{ csrf_token() }}">
<title>@yield('title','UVCI') — Gestion des heures</title>
<link rel="icon" type="image/x-icon" href="/favicon.ico">
<link rel="icon" type="image/png" sizes="192x192" href="/uvci_logo_192.png">
<link rel="icon" type="image/png" sizes="512x512" href="/uvci_logo_512.png">
<link rel="apple-touch-icon" href="/uvci_logo_192.png">
@vite(['resources/css/app.css', 'resources/js/app.js'])
@stack('styles')
</head>
<body class="bg-[#F4F6FA] text-navy min-h-screen font-sans">

{{-- Overlay mobile --}}
<div id="overlay"
     onclick="closeSidebar()"
     class="hidden fixed inset-0 bg-black/50 z-[99]"></div>

{{-- ════ SIDEBAR ════════════════════════════════════════════ --}}
<aside id="sidebar"
       class="fixed top-0 left-0 bottom-0 w-60 bg-navy flex flex-col z-[100]
              -translate-x-full lg:translate-x-0 transition-transform duration-300">

  {{-- Logo --}}
  <div class="flex items-center gap-2.5 px-4 py-[18px] border-b border-white/[0.07]">
    <div class="w-9 h-9 bg-green rounded-[9px] flex items-center justify-center
                font-extrabold text-sm text-navy shrink-0">UV</div>
    <div class="flex-1 min-w-0">
      <span class="block font-bold text-sm text-white">UVCI</span>
      <span class="block text-[10px] text-white/35 mt-0.5 truncate">
        @yield('sidebar-role','Gestion')
      </span>
    </div>
    {{-- Bouton fermer (mobile seulement) --}}
    <button onclick="closeSidebar()"
            class="lg:hidden bg-transparent border-0 text-white/40 cursor-pointer p-1">
      <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/>
      </svg>
    </button>
  </div>

  {{-- Navigation --}}
  <nav class="flex-1 px-2.5 py-3 overflow-y-auto flex flex-col gap-0.5">
    @yield('sidebar-nav')
  </nav>

  {{-- Utilisateur connecté --}}
  <div class="p-2.5 border-t border-white/[0.07]">
    <div class="flex items-center gap-2.5 px-3 py-2.5 rounded-lg hover:bg-white/[0.07] transition-colors">
      <div class="w-[34px] h-[34px] rounded-[10px] bg-green flex items-center justify-center
                  font-bold text-[13px] text-navy shrink-0">
        {{ auth()->user()?->enseignant?->initiales ?? strtoupper(substr(auth()->user()?->login ?? 'U',0,2)) }}
      </div>
      <div class="flex-1 min-w-0">
        <div class="text-[13px] font-medium text-white truncate max-w-[120px]">
          {{ auth()->user()?->enseignant?->nom_complet ?? auth()->user()?->login }}
        </div>
        <div class="text-[10px] text-white/35 capitalize mt-0.5">
          {{ auth()->user()?->role }}
        </div>
      </div>
      <form method="POST" action="{{ route('logout') }}">
        @csrf
        <button type="submit" title="Déconnexion"
                class="bg-transparent border-0 cursor-pointer text-white/30 p-1 rounded-md
                       hover:text-red-400 transition-colors shrink-0">
          <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round"
                  d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/>
          </svg>
        </button>
      </form>
    </div>
  </div>
</aside>

{{-- ════ MAIN ════════════════════════════════════════════════ --}}
<div class="lg:ml-60 min-h-screen flex flex-col">

  {{-- Topbar --}}
  <header class="bg-white border-b border-[#E2E8F0] h-16 flex items-center justify-between
                 px-4 lg:px-7 sticky top-0 z-50">
    <div class="flex items-center gap-3">
      {{-- Burger mobile --}}
      <button onclick="openSidebar()"
              class="lg:hidden flex items-center justify-center p-1.5 rounded-lg
                     hover:bg-[#F4F6FA] transition-colors border-0 bg-transparent cursor-pointer">
        <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" d="M4 6h16M4 12h16M4 18h16"/>
        </svg>
      </button>
      <div>
        <div class="font-bold text-[17px] text-navy">@yield('page-title','Dashboard')</div>
        @hasSection('page-subtitle')
        <div class="text-xs text-[#6B7A8D] mt-0.5">@yield('page-subtitle')</div>
        @endif
      </div>
    </div>
    <div class="flex items-center gap-2">
      @yield('topbar-actions')
    </div>
  </header>

  {{-- Flash messages --}}
  @if(session('success'))
  <div class="mx-4 lg:mx-7 mt-4 px-4 py-3 rounded-xl text-sm font-medium flex items-center gap-2
              bg-green-light border border-green/30 text-green-dark">
    <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
      <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/>
    </svg>
    {{ session('success') }}
  </div>
  @endif
  @if(session('error'))
  <div class="mx-4 lg:mx-7 mt-4 px-4 py-3 rounded-xl text-sm font-medium flex items-center gap-2
              bg-red-50 border border-red-300 text-red-600">
    <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
      <circle cx="12" cy="12" r="10"/>
      <line x1="12" y1="8" x2="12" y2="12"/>
      <line x1="12" y1="16" x2="12.01" y2="16"/>
    </svg>
    {{ session('error') }}
  </div>
  @endif

  {{-- Contenu --}}
  <div class="p-4 lg:p-7 flex-1">
    @yield('content')
  </div>

</div>

<script>
function openSidebar() {
  document.getElementById('sidebar').classList.remove('-translate-x-full');
  document.getElementById('overlay').classList.remove('hidden');
  document.body.style.overflow = 'hidden';
}
function closeSidebar() {
  document.getElementById('sidebar').classList.add('-translate-x-full');
  document.getElementById('overlay').classList.add('hidden');
  document.body.style.overflow = '';
}
</script>
@stack('scripts')
</body>
</html>
