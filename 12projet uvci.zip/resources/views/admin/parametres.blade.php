@extends('layouts.app')
@section('title','Paramètres de calcul')
@section('sidebar-role','Administrateur')
@section('page-title','Paramètres de calcul')
@section('page-subtitle','Définissez les coefficients utilisés pour calculer les volumes horaires')

@section('sidebar-nav')
  <x-nav-item route="admin.dashboard"    label="Tableau de bord"    icon="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/>
  <x-nav-item route="admin.utilisateurs" label="Utilisateurs"       icon="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"/>
  <x-nav-item route="admin.annees"       label="Années académiques" icon="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/>
  <x-nav-item route="admin.parametres"   label="Paramètres calcul"  icon="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
  <x-nav-item route="admin.taux-horaires" label="Taux horaires"     icon="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
@endsection

@section('content')
<div class="max-w-[700px] flex flex-col gap-5">

  {{-- Info formule --}}
  <div class="flex gap-3 bg-green-light border border-green/30 rounded-xl px-5 py-4">
    <div class="shrink-0 mt-0.5">
      <svg width="20" height="20" fill="none" stroke="#009962" stroke-width="1.8" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 11h.01M12 11h.01M15 11h.01M4 19h16a2 2 0 002-2V7a2 2 0 00-2-2H4a2 2 0 00-2 2v10a2 2 0 002 2z"/>
      </svg>
    </div>
    <div>
      <div class="font-semibold text-[13px] text-green-dark mb-1">Formule de calcul</div>
      <div class="text-xs text-[#6B7A8D] leading-relaxed">
        <strong class="text-navy">v_hor = coefficient(type, niveau) × nombre_séquences</strong><br>
        Le <em>type</em> est soit "Création" (1) soit "Mise à jour" (2). Le <em>niveau</em> est la complexité de la ressource (1, 2 ou 3).
      </div>
    </div>
  </div>

  {{-- Formulaire --}}
  <form method="POST" action="{{ route('admin.parametres.update') }}" class="card">
    @csrf @method('PUT')

    <div class="card-header">
      <h3>Coefficients par type et niveau</h3>
    </div>

    <div class="card-body flex flex-col gap-6">

      {{-- Création --}}
      <div>
        <div class="flex items-center gap-2 mb-3.5">
          <span class="badge-green text-xs px-3 py-1">Création de ressource (Type 1)</span>
        </div>
        <div class="grid grid-cols-3 gap-3.5">
          @foreach([
            1=>['label'=>'Niveau 1','desc'=>'Contenus simples + quiz'],
            2=>['label'=>'Niveau 2','desc'=>'Niv.1 + activités interactives'],
            3=>['label'=>'Niveau 3','desc'=>'Serious games, simulations']
          ] as $niv=>$info)
          <div>
            <label class="form-label">{{ $info['label'] }}</label>
            <input type="number" name="creation_niv{{ $niv }}"
                   value="{{ old('creation_niv'.$niv, $coefficients[1][$niv] ?? '') }}"
                   class="form-input" step="0.001" min="0" max="10" required>
            <div class="text-[11px] text-[#6B7A8D] mt-1">{{ $info['desc'] }}</div>
          </div>
          @endforeach
        </div>
        <div class="mt-2.5 text-[11px] text-[#6B7A8D] bg-[#F4F6FA] px-3 py-2 rounded-lg">
          Exemple Niveau 1 : {{ $coefficients[1][1] ?? 0.40 }} × 40 séquences =
          <strong>{{ round(($coefficients[1][1]??0.40)*40,1) }}h</strong>
        </div>
      </div>

      {{-- Mise à jour --}}
      <div>
        <div class="flex items-center gap-2 mb-3.5">
          <span class="badge-orange text-xs px-3 py-1">Mise à jour de ressource (Type 2)</span>
        </div>
        <div class="grid grid-cols-3 gap-3.5">
          @foreach([
            1=>['label'=>'Niveau 1','desc'=>'50% du coefficient création'],
            2=>['label'=>'Niveau 2','desc'=>'50% du coefficient création'],
            3=>['label'=>'Niveau 3','desc'=>'50% du coefficient création']
          ] as $niv=>$info)
          <div>
            <label class="form-label">{{ $info['label'] }}</label>
            <input type="number" name="maj_niv{{ $niv }}"
                   value="{{ old('maj_niv'.$niv, $coefficients[2][$niv] ?? '') }}"
                   class="form-input" step="0.001" min="0" max="10" required>
            <div class="text-[11px] text-[#6B7A8D] mt-1">{{ $info['desc'] }}</div>
          </div>
          @endforeach
        </div>
      </div>

      {{-- Seuil --}}
      <div class="border-t border-[#E2E8F0] pt-5">
        <label class="form-label">Seuil heures complémentaires (h) <span class="text-red-500">*</span></label>
        <div class="flex items-center gap-3 flex-wrap">
          <input type="number" name="seuil" value="{{ old('seuil',$seuil) }}"
                 class="form-input max-w-[180px]" min="1" max="5000" required>
          <span class="text-xs text-[#6B7A8D]">
            Au-delà de ce seuil, les heures sont considérées complémentaires et majorées à 150%.
          </span>
        </div>
        @error('seuil')<div class="form-error">{{ $message }}</div>@enderror
      </div>

    </div>

    <div class="card-footer">
      <span class="text-xs text-[#6B7A8D]">Les modifications s'appliquent aux nouvelles activités enregistrées.</span>
      <button type="submit" class="btn btn-navy">Enregistrer les paramètres</button>
    </div>
  </form>

</div>
@endsection