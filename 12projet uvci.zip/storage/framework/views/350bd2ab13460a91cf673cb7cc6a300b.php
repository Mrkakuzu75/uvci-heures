<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['route','icon','label','badge'=>null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['route','icon','label','badge'=>null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<a href="<?php echo e(route($route)); ?>"
   onclick="closeSidebar()"
   class="flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-[13.5px] no-underline transition-all duration-150
          <?php echo e(request()->routeIs($route)
             ? 'bg-green/15 text-green'
             : 'text-white/55 hover:bg-white/[0.07] hover:text-white/85'); ?>">
  <svg class="w-4 h-4 shrink-0" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
    <path stroke-linecap="round" stroke-linejoin="round" d="<?php echo e($icon); ?>"/>
  </svg>
  <span><?php echo e($label); ?></span>
  <?php if($badge): ?>
  <span class="ml-auto bg-orange text-white text-[10px] font-semibold px-1.5 py-0.5 rounded-full">
    <?php echo e($badge); ?>

  </span>
  <?php endif; ?>
</a>
<?php /**PATH C:\Users\HP\uvci-heures\resources\views/components/nav-item.blade.php ENDPATH**/ ?>