<?php $__env->startSection('title','Secrétaire'); ?>
<?php $__env->startSection('sidebar-role','Secrétaire Principal'); ?>
<?php $__env->startSection('page-title','Tableau de bord'); ?>
<?php $__env->startSection('page-subtitle','Gestion des enseignants et activités pédagogiques'); ?>

<?php $__env->startSection('sidebar-nav'); ?>
  <?php if (isset($component)) { $__componentOriginal6cced52613a484e7295a90162a92d81b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6cced52613a484e7295a90162a92d81b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.nav-item','data' => ['route' => 'secretaire.dashboard','label' => 'Tableau de bord','icon' => 'M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('nav-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['route' => 'secretaire.dashboard','label' => 'Tableau de bord','icon' => 'M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6cced52613a484e7295a90162a92d81b)): ?>
<?php $attributes = $__attributesOriginal6cced52613a484e7295a90162a92d81b; ?>
<?php unset($__attributesOriginal6cced52613a484e7295a90162a92d81b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6cced52613a484e7295a90162a92d81b)): ?>
<?php $component = $__componentOriginal6cced52613a484e7295a90162a92d81b; ?>
<?php unset($__componentOriginal6cced52613a484e7295a90162a92d81b); ?>
<?php endif; ?>
  <?php if (isset($component)) { $__componentOriginal6cced52613a484e7295a90162a92d81b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6cced52613a484e7295a90162a92d81b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.nav-item','data' => ['route' => 'secretaire.enseignants','label' => 'Enseignants','icon' => 'M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('nav-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['route' => 'secretaire.enseignants','label' => 'Enseignants','icon' => 'M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6cced52613a484e7295a90162a92d81b)): ?>
<?php $attributes = $__attributesOriginal6cced52613a484e7295a90162a92d81b; ?>
<?php unset($__attributesOriginal6cced52613a484e7295a90162a92d81b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6cced52613a484e7295a90162a92d81b)): ?>
<?php $component = $__componentOriginal6cced52613a484e7295a90162a92d81b; ?>
<?php unset($__componentOriginal6cced52613a484e7295a90162a92d81b); ?>
<?php endif; ?>
  <?php if (isset($component)) { $__componentOriginal6cced52613a484e7295a90162a92d81b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6cced52613a484e7295a90162a92d81b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.nav-item','data' => ['route' => 'secretaire.cours','label' => 'Cours','icon' => 'M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('nav-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['route' => 'secretaire.cours','label' => 'Cours','icon' => 'M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6cced52613a484e7295a90162a92d81b)): ?>
<?php $attributes = $__attributesOriginal6cced52613a484e7295a90162a92d81b; ?>
<?php unset($__attributesOriginal6cced52613a484e7295a90162a92d81b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6cced52613a484e7295a90162a92d81b)): ?>
<?php $component = $__componentOriginal6cced52613a484e7295a90162a92d81b; ?>
<?php unset($__componentOriginal6cced52613a484e7295a90162a92d81b); ?>
<?php endif; ?>
  <?php if (isset($component)) { $__componentOriginal6cced52613a484e7295a90162a92d81b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6cced52613a484e7295a90162a92d81b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.nav-item','data' => ['route' => 'secretaire.activites','label' => 'Activités','icon' => 'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('nav-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['route' => 'secretaire.activites','label' => 'Activités','icon' => 'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6cced52613a484e7295a90162a92d81b)): ?>
<?php $attributes = $__attributesOriginal6cced52613a484e7295a90162a92d81b; ?>
<?php unset($__attributesOriginal6cced52613a484e7295a90162a92d81b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6cced52613a484e7295a90162a92d81b)): ?>
<?php $component = $__componentOriginal6cced52613a484e7295a90162a92d81b; ?>
<?php unset($__componentOriginal6cced52613a484e7295a90162a92d81b); ?>
<?php endif; ?>
  <?php if (isset($component)) { $__componentOriginal6cced52613a484e7295a90162a92d81b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6cced52613a484e7295a90162a92d81b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.nav-item','data' => ['route' => 'secretaire.paiements','label' => 'États de paiement','icon' => 'M9 14l6-6m-5.5.5h.01m4.99 5h.01M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16l3.5-2 3.5 2 3.5-2 3.5 2z']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('nav-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['route' => 'secretaire.paiements','label' => 'États de paiement','icon' => 'M9 14l6-6m-5.5.5h.01m4.99 5h.01M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16l3.5-2 3.5 2 3.5-2 3.5 2z']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6cced52613a484e7295a90162a92d81b)): ?>
<?php $attributes = $__attributesOriginal6cced52613a484e7295a90162a92d81b; ?>
<?php unset($__attributesOriginal6cced52613a484e7295a90162a92d81b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6cced52613a484e7295a90162a92d81b)): ?>
<?php $component = $__componentOriginal6cced52613a484e7295a90162a92d81b; ?>
<?php unset($__componentOriginal6cced52613a484e7295a90162a92d81b); ?>
<?php endif; ?>
  <?php if (isset($component)) { $__componentOriginal6cced52613a484e7295a90162a92d81b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6cced52613a484e7295a90162a92d81b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.nav-item','data' => ['route' => 'secretaire.statistiques.pdf','label' => 'Statistiques','icon' => 'M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('nav-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['route' => 'secretaire.statistiques.pdf','label' => 'Statistiques','icon' => 'M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6cced52613a484e7295a90162a92d81b)): ?>
<?php $attributes = $__attributesOriginal6cced52613a484e7295a90162a92d81b; ?>
<?php unset($__attributesOriginal6cced52613a484e7295a90162a92d81b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6cced52613a484e7295a90162a92d81b)): ?>
<?php $component = $__componentOriginal6cced52613a484e7295a90162a92d81b; ?>
<?php unset($__componentOriginal6cced52613a484e7295a90162a92d81b); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('topbar-actions'); ?>
  <a href="<?php echo e(route('secretaire.statistiques.pdf', ['annee_id'=>$annee?->id_anee])); ?>"
     target="_blank" class="btn btn-outline">
    <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
      <path stroke-linecap="round" stroke-linejoin="round" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/>
    </svg>
    <span class="btn-text">Statistiques</span>
  </a>
  <a href="<?php echo e(route('secretaire.activites.create')); ?>" class="btn btn-green">
    <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
      <path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4"/>
    </svg>
    <span class="btn-text">Nouvelle activité</span>
  </a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<div class="kpi-grid mb-6">
  <?php $kpis=[
    ['label'=>'Enseignants',      'value'=>$stats['total_enseignants'],             'color'=>'#00C07F',
     'icon'=>'<svg width="28" height="28" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"/></svg>'],
    ['label'=>'Cours',            'value'=>$stats['total_cours'],                   'color'=>'#4A90E2',
     'icon'=>'<svg width="28" height="28" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"/></svg>'],
    ['label'=>'Activités',        'value'=>$stats['total_activites'],               'color'=>'#FF6B35',
     'icon'=>'<svg width="28" height="28" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4"/></svg>'],
    ['label'=>'Volume total (h)', 'value'=>number_format($stats['volume_total'],1), 'color'=>'#9B59B6',
     'icon'=>'<svg width="28" height="28" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path stroke-linecap="round" stroke-linejoin="round" d="M12 7v5l3.5 3.5"/></svg>'],
  ]; ?>
  <?php $__currentLoopData = $kpis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="kpi-card">
    <div class="kpi-icon" style="color:<?php echo e($k['color']); ?>"><?php echo $k['icon']; ?></div>
    <div class="kpi-value"><?php echo e($k['value']); ?></div>
    <div class="kpi-label"><?php echo e($k['label']); ?></div>
    <div class="kpi-bar"><div class="kpi-fill" style="background:<?php echo e($k['color']); ?>;width:65%"></div></div>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>


<div class="flex items-center gap-2 mb-5 px-4 py-2.5 bg-[#F4F6FA] border border-[#E2E8F0] rounded-xl flex-wrap">
  <span class="text-[11px] font-bold text-[#6B7A8D] uppercase tracking-[1px] mr-1">Aller à</span>

  <a href="#section-depassement" class="inline-flex items-center gap-1.5 text-xs font-medium text-navy no-underline
     px-3 py-1.5 rounded-lg bg-white border border-[#E2E8F0] whitespace-nowrap
     hover:border-orange hover:text-orange transition-all">
    <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
      <path stroke-linecap="round" stroke-linejoin="round" d="M12 9v4m0 4h.01M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/>
    </svg>
    Dépassements
  </a>
  <a href="#section-repartition" class="inline-flex items-center gap-1.5 text-xs font-medium text-navy no-underline
     px-3 py-1.5 rounded-lg bg-white border border-[#E2E8F0] whitespace-nowrap
     hover:border-green hover:text-green-dark transition-all">
    <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
      <path stroke-linecap="round" stroke-linejoin="round" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/>
    </svg>
    Répartition
  </a>
  <a href="#section-departements" class="inline-flex items-center gap-1.5 text-xs font-medium text-navy no-underline
     px-3 py-1.5 rounded-lg bg-white border border-[#E2E8F0] whitespace-nowrap
     hover:border-blue-400 hover:text-blue-500 transition-all">
    <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
      <path stroke-linecap="round" stroke-linejoin="round" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/>
    </svg>
    Départements
  </a>
  <a href="#section-mensuelles" class="inline-flex items-center gap-1.5 text-xs font-medium text-navy no-underline
     px-3 py-1.5 rounded-lg bg-white border border-[#E2E8F0] whitespace-nowrap
     hover:border-purple-400 hover:text-purple-600 transition-all">
    <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
      <rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>
    </svg>
    Mensuel
  </a>
  <a href="#section-enseignants" class="inline-flex items-center gap-1.5 text-xs font-medium text-navy no-underline
     px-3 py-1.5 rounded-lg bg-white border border-[#E2E8F0] whitespace-nowrap
     hover:border-navy hover:text-navy transition-all">
    <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
      <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"/>
    </svg>
    Enseignants
  </a>
</div>


<div id="section-depassement" class="scroll-mt-20"></div>
<?php
  $enseignantsDepasses = $enseignants->getCollection()->filter(fn($e) => ($e->volume_horaire ?? 0) > $seuil);
  $nbDepasses = $enseignantsDepasses->count();
?>

<?php if($nbDepasses > 0): ?>
<div class="mb-6">
  <div class="bg-[#FFF5E6] border border-[#FFB347] border-l-4 border-l-orange rounded-xl p-4 lg:p-5">
    <div class="flex items-start gap-3 mb-4">
      <svg width="20" height="20" fill="none" stroke="#FF6B35" stroke-width="2" viewBox="0 0 24 24" class="shrink-0 mt-0.5">
        <path stroke-linecap="round" stroke-linejoin="round" d="M12 9v4m0 4h.01M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/>
      </svg>
      <div>
        <div class="font-bold text-[14px] text-[#C05000]">
          <?php echo e($nbDepasses); ?> enseignant(s) ont dépassé la charge de <?php echo e($seuil); ?>h
        </div>
        <div class="text-xs text-[#A04000] mt-0.5">
          Les heures au-delà de <?php echo e($seuil); ?>h sont majorées à 150% du taux horaire
        </div>
      </div>
    </div>
    <div class="flex flex-col gap-2">
      <?php $__currentLoopData = $enseignantsDepasses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ens): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php
        $vol   = (float)($ens->volume_horaire ?? 0);
        $compl = round($vol - $seuil, 1);
        $pct   = round($vol / $seuil * 100);
      ?>
      <div class="bg-white rounded-lg px-3.5 py-2.5 flex items-center gap-3 flex-wrap">
        <div class="avatar av-orange shrink-0"><?php echo e($ens->initiales); ?></div>
        <div class="flex-1 min-w-[120px]">
          <div class="font-semibold text-[13px] text-navy"><?php echo e($ens->nom_complet); ?></div>
          <div class="text-[11px] text-[#6B7A8D]"><?php echo e($ens->grade?->lib_grd); ?> — <?php echo e($ens->departement?->lib_dep); ?></div>
        </div>
        <div class="flex items-center gap-4 shrink-0">
          <div class="text-center">
            <div class="text-[16px] font-bold text-orange"><?php echo e(number_format($vol,1)); ?>h</div>
            <div class="text-[10px] text-[#6B7A8D]">Volume total</div>
          </div>
          <div class="text-center">
            <div class="text-[16px] font-bold text-[#C05000]">+<?php echo e($compl); ?>h</div>
            <div class="text-[10px] text-[#6B7A8D]">Complémentaires</div>
          </div>
          <div class="text-center">
            <span class="bg-orange text-white text-[11px] font-bold px-2.5 py-0.5 rounded-full"><?php echo e($pct); ?>%</span>
            <div class="text-[10px] text-[#6B7A8D] mt-0.5">de la charge</div>
          </div>
        </div>
        <div class="w-full mt-1.5">
          <div class="h-1.5 bg-[#FFE0C0] rounded-full overflow-hidden flex">
            <div class="h-full bg-green rounded-l-full" style="width:<?php echo e(min(round($seuil/$vol*100),100)); ?>%"></div>
            <div class="h-full bg-orange rounded-r-full" style="width:<?php echo e(round($compl/$vol*100)); ?>%"></div>
          </div>
          <div class="flex justify-between text-[9px] text-[#6B7A8D] mt-1">
            <span class="text-green">■ Normal (<?php echo e(number_format(min($vol,$seuil),1)); ?>h)</span>
            <span class="text-orange">■ Complémentaire (+<?php echo e($compl); ?>h)</span>
          </div>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</div>
<?php else: ?>
<div class="mb-6">
  <div class="bg-green-light border border-green/25 border-l-4 border-l-green rounded-xl px-5 py-3.5 flex items-center gap-3">
    <svg width="18" height="18" fill="none" stroke="#00C07F" stroke-width="2" viewBox="0 0 24 24" class="shrink-0">
      <path stroke-linecap="round" stroke-linejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
    </svg>
    <div class="text-[13px] text-green-dark font-medium">
      Aucun enseignant n'a dépassé la charge de <?php echo e($seuil); ?>h pour <?php echo e($annee?->lib_anee ?? 'cette année'); ?>

    </div>
  </div>
</div>
<?php endif; ?>


<div id="section-repartition" class="scroll-mt-20 mb-6">
  <h2 class="font-bold text-[15px] text-navy mb-3.5 flex items-center gap-2">
    <svg width="16" height="16" fill="none" stroke="#00C07F" stroke-width="2" viewBox="0 0 24 24">
      <path stroke-linecap="round" stroke-linejoin="round" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/>
    </svg>
    Répartition des activités pédagogiques
    <span class="text-xs font-normal text-[#6B7A8D]">— <?php echo e($annee?->lib_anee ?? 'Toutes années'); ?></span>
  </h2>
  <div class="grid-auto">

    
    <div class="card">
      <div class="card-header"><h3>Par type d'activité</h3></div>
      <div class="p-5">
        <?php $totalVol=$repartitionTypes->sum('volume_total')?: 1; $tc=['#00C07F','#FF6B35']; ?>
        <?php if($repartitionTypes->isEmpty()): ?>
          <p class="text-[#6B7A8D] text-[13px] text-center py-4">Aucune activité</p>
        <?php else: ?>
        <div class="flex items-center gap-5">
          <svg width="100" height="100" viewBox="0 0 100 100" class="shrink-0">
            <?php $a=-90; ?>
            <?php $__currentLoopData = $repartitionTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ti=>$t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php $p=$t->volume_total/$totalVol;$sw=$p*360;$r=38;$c=2*M_PI*$r;$d=$p*$c;$o=-($a/360)*$c; ?>
              <circle cx="50" cy="50" r="<?php echo e($r); ?>" fill="none" stroke="<?php echo e($tc[$ti%2]); ?>" stroke-width="16"
                stroke-dasharray="<?php echo e($d); ?> <?php echo e($c); ?>" stroke-dashoffset="<?php echo e($o); ?>"/>
              <?php $a+=$sw; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <circle cx="50" cy="50" r="22" fill="white"/>
            <text x="50" y="47" text-anchor="middle" style="font-size:10px;font-weight:700;fill:#0D1B2A;"><?php echo e(number_format($totalVol,0)); ?></text>
            <text x="50" y="59" text-anchor="middle" style="font-size:8px;fill:#6B7A8D;">heures</text>
          </svg>
          <div class="flex-1">
            <?php $__currentLoopData = $repartitionTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ti=>$t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="mb-2.5">
              <div class="flex justify-between items-center mb-1">
                <div class="flex items-center gap-1.5">
                  <span class="w-2 h-2 rounded-full shrink-0 inline-block" style="background:<?php echo e($tc[$ti%2]); ?>"></span>
                  <span class="text-xs text-navy"><?php echo e($t->lib_typ_act); ?></span>
                </div>
                <span class="text-xs font-bold"><?php echo e(number_format($t->volume_total,1)); ?>h</span>
              </div>
              <div class="h-1.5 bg-[#E2E8F0] rounded-full overflow-hidden">
                <div class="h-full rounded-full" style="background:<?php echo e($tc[$ti%2]); ?>;width:<?php echo e(round($t->volume_total/$totalVol*100)); ?>%"></div>
              </div>
              <div class="text-[10px] text-[#6B7A8D] mt-0.5"><?php echo e($t->nb_activites); ?> activité(s) — <?php echo e(round($t->volume_total/$totalVol*100)); ?>%</div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
        <?php endif; ?>
      </div>
    </div>

    
    <div class="card">
      <div class="card-header"><h3>Par niveau de complexité</h3></div>
      <div class="p-5">
        <?php $maxN=$repartitionNiveaux->max('volume_total')?:1; $nc=[1=>'#4A90E2',2=>'#00C07F',3=>'#9B59B6']; $nd=[1=>'Contenus simples + quiz',2=>'Niv.1 + interactifs',3=>'Serious games']; ?>
        <?php if($repartitionNiveaux->isEmpty()): ?>
          <p class="text-[#6B7A8D] text-[13px] text-center py-4">Aucune activité</p>
        <?php else: ?>
        <div class="flex flex-col gap-3.5">
          <?php $__currentLoopData = $repartitionNiveaux; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $niv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php $p2=round($niv->volume_total/$maxN*100); ?>
          <div>
            <div class="flex justify-between items-center mb-1.5">
              <div class="flex items-center gap-2">
                <span class="w-6 h-6 rounded-lg inline-flex items-center justify-center font-bold text-[11px] shrink-0"
                  style="background:<?php echo e(($nc[$niv->niv_comp]??'#ccc')); ?>20;border:1px solid <?php echo e(($nc[$niv->niv_comp]??'#ccc')); ?>50;color:<?php echo e($nc[$niv->niv_comp]??'#ccc'); ?>">
                  N<?php echo e($niv->niv_comp); ?>

                </span>
                <div>
                  <div class="text-[12.5px] font-medium text-navy">Niveau <?php echo e($niv->niv_comp); ?></div>
                  <div class="text-[10px] text-[#6B7A8D]"><?php echo e($nd[$niv->niv_comp]??''); ?></div>
                </div>
              </div>
              <div class="text-right shrink-0">
                <div class="text-[13px] font-bold"><?php echo e(number_format($niv->volume_total,1)); ?>h</div>
                <div class="text-[10px] text-[#6B7A8D]"><?php echo e($niv->nb_activites); ?> acte(s)</div>
              </div>
            </div>
            <div class="h-2 bg-[#E2E8F0] rounded-full overflow-hidden">
              <div class="h-full rounded-full" style="background:<?php echo e($nc[$niv->niv_comp]??'#ccc'); ?>;width:<?php echo e($p2); ?>%"></div>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>
      </div>
    </div>

    
    <div class="card">
      <div class="card-header"><h3>Par type de ressource</h3></div>
      <div class="p-5">
        <?php $maxR=$repartitionRessources->max('volume_total')?:1; $rc=['#00C07F','#4A90E2','#FF6B35','#9B59B6','#1ABC9C','#E74C3C','#F39C12','#3498DB']; ?>
        <?php if($repartitionRessources->isEmpty()): ?>
          <p class="text-[#6B7A8D] text-[13px] text-center py-4">Aucune activité</p>
        <?php else: ?>
        <div class="flex flex-col gap-2">
          <?php $__currentLoopData = $repartitionRessources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ri=>$r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php $pr=round($r->volume_total/$maxR*100); ?>
          <div class="flex items-center gap-2.5">
            <div class="w-[110px] text-[11px] text-[#6B7A8D] text-right shrink-0 truncate" title="<?php echo e($r->lib_typ_ress); ?>"><?php echo e($r->lib_typ_ress); ?></div>
            <div class="flex-1 h-4 bg-[#E2E8F0] rounded overflow-hidden">
              <div class="h-full rounded" style="background:<?php echo e($rc[$ri%count($rc)]); ?>;width:<?php echo e($pr); ?>%"></div>
            </div>
            <div class="w-9 text-[11px] font-bold text-right shrink-0"><?php echo e(number_format($r->volume_total,1)); ?>h</div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>
      </div>
    </div>

  </div>
</div>


<div id="section-departements" class="scroll-mt-20 mb-6">
  <h2 class="font-bold text-[15px] text-navy mb-3.5 flex items-center gap-2">
    <svg width="16" height="16" fill="none" stroke="#00C07F" stroke-width="2" viewBox="0 0 24 24">
      <path stroke-linecap="round" stroke-linejoin="round" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/>
    </svg>
    Volume horaire par département
    <span class="text-xs font-normal text-[#6B7A8D]">— <?php echo e($annee?->lib_anee ?? 'Toutes années'); ?></span>
  </h2>
  <div class="card">
    <div class="card-header">
      <h3>Répartition par département</h3>
      <span class="text-xs text-[#6B7A8D]"><?php echo e($volumeParDepartement->count()); ?> département(s)</span>
    </div>
    <?php $maxDep=$volumeParDepartement->max('volume_total')?:1; $totDep=$volumeParDepartement->sum('volume_total')?:1; $dc=['#00C07F','#4A90E2','#FF6B35','#9B59B6','#1ABC9C','#E74C3C']; ?>
    <?php if($volumeParDepartement->isEmpty()): ?>
      <div class="p-8 text-center text-[#6B7A8D] text-[13px]">Aucune donnée</div>
    <?php else: ?>
    <div class="px-6 py-5 flex flex-col gap-3.5">
      <?php $__currentLoopData = $volumeParDepartement; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $di=>$dep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php $pd=$maxDep>0?round($dep->volume_total/$maxDep*100):0; ?>
      <div>
        <div class="flex items-center justify-between mb-1.5 gap-3">
          <div class="flex items-center gap-2 min-w-0 flex-1">
            <span class="w-2.5 h-2.5 rounded-full shrink-0 inline-block" style="background:<?php echo e($dc[$di%6]); ?>"></span>
            <span class="text-[13px] font-medium text-navy truncate" title="<?php echo e($dep->lib_dep); ?>"><?php echo e($dep->lib_dep); ?></span>
          </div>
          <div class="flex items-center gap-5 shrink-0">
            <span class="text-[11px] text-[#6B7A8D] whitespace-nowrap"><?php echo e($dep->nb_enseignants); ?> ens.</span>
            <span class="text-[11px] text-[#6B7A8D] whitespace-nowrap"><?php echo e($dep->nb_activites); ?> act.</span>
            <span class="text-[15px] font-bold text-navy whitespace-nowrap"><?php echo e(number_format($dep->volume_total,1)); ?>h</span>
          </div>
        </div>
        <div class="h-2.5 bg-[#E2E8F0] rounded-full overflow-hidden">
          <div class="h-full rounded-full" style="background:<?php echo e($dc[$di%6]); ?>;width:<?php echo e($pd); ?>%"></div>
        </div>
        <div class="text-[10px] text-[#6B7A8D] mt-0.5 text-right"><?php echo e(round($dep->volume_total/$totDep*100,1)); ?>% du volume total</div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="table-wrap border-t border-[#E2E8F0]">
      <table>
        <thead>
          <tr>
            <th>Département</th>
            <th class="text-center">Enseignants</th>
            <th class="text-center">Activités</th>
            <th class="text-right">Volume (h)</th>
            <th class="text-right">Part (%)</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $volumeParDepartement; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $di=>$dep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td>
              <div class="flex items-center gap-2">
                <span class="w-2 h-2 rounded-full shrink-0 inline-block" style="background:<?php echo e($dc[$di%6]); ?>"></span>
                <span class="text-[13px]"><?php echo e($dep->lib_dep); ?></span>
              </div>
            </td>
            <td class="text-center text-[13px] text-[#6B7A8D]"><?php echo e($dep->nb_enseignants); ?></td>
            <td class="text-center text-[13px] text-[#6B7A8D]"><?php echo e($dep->nb_activites); ?></td>
            <td class="text-right font-bold text-[14px]" style="color:<?php echo e($dc[$di%6]); ?>"><?php echo e(number_format($dep->volume_total,1)); ?>h</td>
            <td class="text-right text-[12px] text-[#6B7A8D]"><?php echo e(round($dep->volume_total/$totDep*100,1)); ?>%</td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot>
          <tr class="bg-green-light border-t-2 border-[#E2E8F0]">
            <td class="font-bold text-[13px] px-4 py-3">TOTAL</td>
            <td class="text-center font-bold px-4 py-3"><?php echo e($volumeParDepartement->sum('nb_enseignants')); ?></td>
            <td class="text-center font-bold px-4 py-3"><?php echo e($volumeParDepartement->sum('nb_activites')); ?></td>
            <td class="text-right font-bold text-[15px] text-green-dark px-4 py-3"><?php echo e(number_format($volumeParDepartement->sum('volume_total'),1)); ?>h</td>
            <td class="text-right font-bold px-4 py-3">100%</td>
          </tr>
        </tfoot>
      </table>
    </div>
    <?php endif; ?>
  </div>
</div>


<div id="section-mensuelles" class="scroll-mt-20 mb-6">
  <h2 class="font-bold text-[15px] text-navy mb-3.5 flex items-center gap-2">
    <svg width="16" height="16" fill="none" stroke="#00C07F" stroke-width="2" viewBox="0 0 24 24">
      <path stroke-linecap="round" stroke-linejoin="round" d="M7 12l3-3 3 3 4-4M8 21l4-4 4 4M3 4h18M4 4h16v12a1 1 0 01-1 1H5a1 1 0 01-1-1V4z"/>
    </svg>
    Statistiques mensuelles
    <span class="text-xs font-normal text-[#6B7A8D]">— <?php echo e($annee?->lib_anee ?? 'Toutes années'); ?></span>
  </h2>
  <?php $moisNoms = ['Jan','Fév','Mar','Avr','Mai','Jun','Jul','Aoû','Sep','Oct','Nov','Déc']; ?>
  <div class="card">
    <div class="card-header">
      <h3>Évolution mensuelle des volumes horaires</h3>
      <?php
        $totalAnnee  = $statsMensuelles->sum('volume');
        $moisActif   = $statsMensuelles->filter(fn($m) => $m['volume'] > 0)->count();
        $moyenneMois = $moisActif > 0 ? round($totalAnnee / $moisActif, 1) : 0;
        $maxMois     = $statsMensuelles->max('volume') ?: 1;
        $moisPic     = $statsMensuelles->sortByDesc('volume')->first();
      ?>
      <span class="text-xs text-[#6B7A8D]">Total : <strong class="text-navy"><?php echo e(number_format($totalAnnee,1)); ?>h</strong></span>
    </div>

    
    <div class="grid grid-cols-2 lg:grid-cols-4 border-b border-[#E2E8F0]">
      <div class="px-5 py-3.5 border-r border-[#E2E8F0]">
        <div class="text-[11px] text-[#6B7A8D] uppercase tracking-[.5px] mb-1">Total annuel</div>
        <div class="text-[22px] font-bold text-navy"><?php echo e(number_format($totalAnnee,1)); ?><span class="text-[13px] font-normal text-[#6B7A8D] ml-1">h</span></div>
      </div>
      <div class="px-5 py-3.5 border-r border-[#E2E8F0]">
        <div class="text-[11px] text-[#6B7A8D] uppercase tracking-[.5px] mb-1">Mois actifs</div>
        <div class="text-[22px] font-bold text-navy"><?php echo e($moisActif); ?><span class="text-[13px] font-normal text-[#6B7A8D] ml-1">/ 12</span></div>
      </div>
      <div class="px-5 py-3.5 border-r border-[#E2E8F0]">
        <div class="text-[11px] text-[#6B7A8D] uppercase tracking-[.5px] mb-1">Moy. par mois</div>
        <div class="text-[22px] font-bold text-green"><?php echo e($moyenneMois); ?><span class="text-[13px] font-normal text-[#6B7A8D] ml-1">h</span></div>
      </div>
      <div class="px-5 py-3.5">
        <div class="text-[11px] text-[#6B7A8D] uppercase tracking-[.5px] mb-1">Mois pic</div>
        <div class="text-[16px] font-bold text-orange">
          <?php echo e($moisPic && $moisPic['volume'] > 0 ? $moisNoms[$moisPic['mois']-1] : '—'); ?>

          <?php if($moisPic && $moisPic['volume'] > 0): ?>
          <span class="text-[12px] text-[#6B7A8D] font-normal">(<?php echo e(number_format($moisPic['volume'],1)); ?>h)</span>
          <?php endif; ?>
        </div>
      </div>
    </div>

    
    <div class="p-5 lg:p-6">
      <?php $moisCourant = (int)date('n'); ?>
      <div class="flex items-end gap-1.5 h-[140px] pb-7 relative border-b-2 border-[#E2E8F0]">
        <?php $__currentLoopData = [25,50,75,100]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pctGrid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="absolute left-0 right-0 border-t border-dashed border-[#E8ECF0] z-0"
             style="bottom:<?php echo e(28 + $pctGrid * 112/100); ?>px"></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php $__currentLoopData = $statsMensuelles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
          $h        = $maxMois > 0 ? round($m['volume'] / $maxMois * 112) : 0;
          $isActuel = $m['mois'] === $moisCourant;
        ?>
        <div class="flex-1 flex flex-col items-center gap-1 relative z-10" style="padding-bottom:0">
          <?php if($m['volume'] > 0): ?>
          <div class="text-[8px] font-bold text-[#6B7A8D] absolute" style="bottom:<?php echo e($h + 30); ?>px">
            <?php echo e(number_format($m['volume'],0)); ?>

          </div>
          <?php endif; ?>
          <div class="w-full rounded-t-[3px] absolute bottom-7 transition-all"
               style="height:<?php echo e($h); ?>px;background:<?php echo e($isActuel ? '#0D1B2A' : ($m['volume']>0 ? '#00C07F' : '#E2E8F0')); ?>;opacity:<?php echo e($m['volume']>0 ? 1 : 0.4); ?>">
          </div>
          <div class="absolute bottom-0 text-[9px] <?php echo e($isActuel ? 'font-bold text-navy' : 'text-[#6B7A8D]'); ?>">
            <?php echo e($moisNoms[$m['mois']-1]); ?>

          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>

      
      <div class="overflow-x-auto mt-4 border border-[#E2E8F0] rounded-xl">
        <table class="w-full text-center" style="min-width:700px;">
          <thead>
            <tr class="bg-[#FAFBFC]">
              <th class="px-3 py-2.5 text-left text-[11px] font-medium text-[#6B7A8D] uppercase tracking-[.5px]">Indicateur</th>
              <?php $__currentLoopData = $statsMensuelles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ms): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <th class="px-1.5 py-2.5 text-[11px] font-medium text-[#6B7A8D] uppercase tracking-[.5px]"><?php echo e($moisNoms[$ms['mois']-1]); ?></th>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <th class="px-3 py-2.5 text-right text-[11px] font-medium text-[#6B7A8D] uppercase tracking-[.5px]">Total</th>
            </tr>
          </thead>
          <tbody>
            <tr class="border-t border-[#F0F2F5]">
              <td class="px-3 py-2.5 text-[12px] font-medium text-navy text-left">Volume (h)</td>
              <?php $__currentLoopData = $statsMensuelles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ms): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <td class="px-1.5 py-2.5 text-[12px] <?php echo e($ms['volume']>0?'font-bold text-green-dark':'text-[#6B7A8D]'); ?>">
                <?php echo e($ms['volume'] > 0 ? number_format($ms['volume'],1) : '—'); ?>

              </td>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <td class="px-3 py-2.5 text-right font-bold text-[13px] text-navy"><?php echo e(number_format($totalAnnee,1)); ?>h</td>
            </tr>
            <tr class="border-t border-[#F0F2F5]">
              <td class="px-3 py-2.5 text-[12px] font-medium text-navy text-left">Activités</td>
              <?php $__currentLoopData = $statsMensuelles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ms): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <td class="px-1.5 py-2.5 text-[12px] <?php echo e($ms['nb_activites']>0?'text-navy':'text-[#6B7A8D]'); ?>">
                <?php echo e($ms['nb_activites'] > 0 ? $ms['nb_activites'] : '—'); ?>

              </td>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <td class="px-3 py-2.5 text-right font-bold text-[13px] text-navy"><?php echo e($statsMensuelles->sum('nb_activites')); ?></td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>


<div id="section-enseignants" class="scroll-mt-20">
  <h2 class="font-bold text-[15px] text-navy mb-3.5 flex items-center gap-2">
    <svg width="16" height="16" fill="none" stroke="#00C07F" stroke-width="2" viewBox="0 0 24 24">
      <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"/>
    </svg>
    Enseignants
    <span class="text-xs font-normal text-[#6B7A8D]">— <?php echo e($annee?->lib_anee ?? 'Aucune année active'); ?></span>
  </h2>
  <div class="card">
    <div class="card-header">
      <h3><?php echo e($enseignants->total()); ?> enseignant(s)</h3>
      <a href="<?php echo e(route('secretaire.enseignants.create')); ?>" class="btn btn-green btn-sm">+ Ajouter</a>
    </div>

    
    <div class="px-4 py-2.5 border-b border-[#E2E8F0] flex gap-2.5 flex-wrap">
      <div class="relative flex-1 min-w-[160px]">
        <svg class="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-[#6B7A8D] pointer-events-none"
             fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
          <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
        </svg>
        <input type="text" id="srch" oninput="ft()" placeholder="Rechercher…"
               class="w-full pl-8 pr-3 py-1.5 border-[1.5px] border-[#E2E8F0] rounded-lg text-[13px]
                      bg-[#FAFAFA] text-navy outline-none font-[inherit]
                      focus:border-green transition-colors">
      </div>
      <select id="fst" onchange="ft()"
              class="px-3 py-1.5 border-[1.5px] border-[#E2E8F0] rounded-lg text-[13px]
                     bg-[#FAFAFA] text-navy outline-none cursor-pointer font-[inherit]
                     focus:border-green transition-colors">
        <option value="">Tous statuts</option>
        <option value="permanent">Permanent</option>
        <option value="vacataire">Vacataire</option>
      </select>
    </div>

    <div class="table-wrap">
      <table id="et">
        <thead>
          <tr>
            <th>Enseignant</th>
            <th>Grade</th>
            <th class="hide-mobile">Statut</th>
            <th class="hide-mobile">Département</th>
            <th class="text-right">Volume (h)</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php $avc=['av-green','av-blue','av-purple','av-orange','av-teal']; ?>
          <?php $__empty_1 = true; $__currentLoopData = $enseignants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ens): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <?php $vol2=(float)($ens->volume_horaire??0); $depasse=$vol2>$seuil; ?>
          <tr data-statut="<?php echo e(strtolower($ens->statut?->lib_stat??'')); ?>"
              data-nom="<?php echo e(strtolower($ens->nom_complet)); ?>"
              class="<?php echo e($depasse ? 'bg-[#FFF8F0]' : ''); ?>">
            <td>
              <div class="flex items-center gap-2.5">
                <div class="avatar <?php echo e($depasse ? 'av-orange' : $avc[$loop->index%5]); ?>"><?php echo e($ens->initiales); ?></div>
                <div>
                  <div class="font-medium text-[13.5px]"><?php echo e($ens->nom_complet); ?></div>
                  <div class="text-[11px] text-[#6B7A8D]"><?php echo e($ens->utilisateur?->email ?? '—'); ?></div>
                </div>
              </div>
            </td>
            <td><span class="badge-green"><?php echo e($ens->grade?->lib_grd ?? '—'); ?></span></td>
            <td class="hide-mobile">
              <?php if(strtolower($ens->statut?->lib_stat??'') === 'permanent'): ?>
                <span class="badge-blue">Permanent</span>
              <?php else: ?>
                <span class="badge-orange">Vacataire</span>
              <?php endif; ?>
            </td>
            <td class="hide-mobile text-[13px] text-[#6B7A8D]"><?php echo e($ens->departement?->lib_dep ?? '—'); ?></td>
            <td class="text-right">
              <span class="text-[14px] font-bold <?php echo e($depasse ? 'text-orange' : 'text-navy'); ?>"><?php echo e(number_format($vol2,1)); ?>h</span>
              <?php if($depasse): ?>
              <div class="text-[10px] text-orange mt-0.5 flex items-center justify-end gap-1">
                +<?php echo e(round($vol2-$seuil,1)); ?>h
                <svg width="11" height="11" fill="none" stroke="#FF6B35" stroke-width="2" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" d="M12 9v4m0 4h.01M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/>
                </svg>
              </div>
              <?php endif; ?>
            </td>
            <td>
              <div class="flex gap-1.5">
                <a href="<?php echo e(route('secretaire.enseignants.edit',$ens)); ?>" class="btn btn-outline btn-sm">Modifier</a>
                <form method="POST" action="<?php echo e(route('secretaire.enseignants.destroy',$ens)); ?>"
                      onsubmit="return confirm('Supprimer ?')">
                  <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                  <button type="submit" class="btn btn-danger btn-sm">Suppr.</button>
                </form>
              </div>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr>
            <td colspan="6" class="text-center py-10 text-[#6B7A8D]">Aucun enseignant</td>
          </tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
    <?php if($enseignants->hasPages()): ?>
    <div class="px-4 py-3.5 border-t border-[#E2E8F0]"><?php echo e($enseignants->links()); ?></div>
    <?php endif; ?>
  </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
function ft(){
  var s=document.getElementById('srch').value.toLowerCase();
  var st=document.getElementById('fst').value.toLowerCase();
  document.querySelectorAll('#et tbody tr[data-nom]').forEach(function(r){
    r.style.display=(!s||r.dataset.nom.includes(s))&&(!st||r.dataset.statut.includes(st))?'':'none';
  });
}
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\HP\uvci-heures\resources\views/secretaire/dashboard.blade.php ENDPATH**/ ?>