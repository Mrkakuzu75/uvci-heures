<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>UVCI — Connexion</title>
<link rel="icon" type="image/x-icon" href="/favicon.ico">
<?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css','resources/js/app.js']); ?>
<style>
@keyframes blob{
  0%,100%{transform:translate(0,0) scale(1) rotate(0deg)}
  33%    {transform:translate(30px,-20px) scale(1.08) rotate(3deg)}
  66%    {transform:translate(-20px,25px) scale(.95) rotate(-2deg)}
}
@keyframes pulse{0%,100%{opacity:1;transform:scale(1)}50%{opacity:.35;transform:scale(.7)}}

.blob{position:absolute;border-radius:50%;filter:blur(100px);opacity:.09}
.b1{width:760px;height:760px;background:#00C07F;top:-280px;left:-200px;animation:blob 18s ease-in-out infinite}
.b2{width:560px;height:560px;background:#FF6B35;bottom:-220px;right:-180px;animation:blob 14s ease-in-out infinite reverse;animation-delay:-6s}
.b3{width:400px;height:400px;background:#5B8DEF;top:30%;left:30%;animation:blob 11s ease-in-out infinite;animation-delay:-4s}
.pdot{animation:pulse 2.4s ease-in-out infinite}

#p1{transition:opacity .65s cubic-bezier(.4,0,.2,1),transform .65s cubic-bezier(.4,0,.2,1)}
#p1.out{opacity:0;transform:translateY(-18px) scale(.97);pointer-events:none}
#p2{opacity:0;pointer-events:none;transition:opacity .6s cubic-bezier(.4,0,.2,1),transform .6s cubic-bezier(.4,0,.2,1);transform:translateY(24px)}
#p2.in{opacity:1;pointer-events:all;transform:translateY(0)}

/* Sélecteur de rôle */
.rgrid input[type=radio]{display:none}
.rgrid input:checked + .rc{
  border-color:#00C07F;
  background:linear-gradient(160deg,#f0fdf8 0%,#E6FBF3 100%);
  box-shadow:0 4px 14px rgba(0,192,127,.15);
}
.rgrid label:hover .rc{border-color:rgba(0,192,127,.4)}
.rchk{display:none}
.rgrid input:checked + .rc .rchk{display:flex}
.rgrid input:checked + .rc .rnam{color:#009962;font-weight:700}
.rgrid input:checked + .rc .rico{color:#009962}
</style>
</head>
<body class="bg-navy min-h-screen overflow-hidden font-sans">


<div class="fixed inset-0 pointer-events-none z-0 overflow-hidden">
  <div class="blob b1"></div>
  <div class="blob b2"></div>
  <div class="blob b3"></div>
</div>


<div class="fixed inset-0 z-0"
     style="background:linear-gradient(rgba(255,255,255,.022) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.022) 1px,transparent 1px);background-size:60px 60px"></div>

<div class="fixed inset-0 z-10">

  
  <div id="p1" class="absolute inset-0 flex flex-col items-center justify-center px-7 pt-[72px] pb-8 text-center">

    
    <div class="absolute top-8 left-1/2 -translate-x-1/2 flex items-center gap-3 whitespace-nowrap">
      <div class="w-10 h-10 bg-green rounded-[10px] flex items-center justify-center font-black text-[16px] text-navy shrink-0">UV</div>
      <div>
        <span class="block font-bold text-[14.5px] text-white">UVCI</span>
        <span class="block text-[10.5px] text-white/35 mt-0.5">Université Virtuelle de Côte d'Ivoire</span>
      </div>
    </div>

    
    <div class="inline-flex items-center gap-2 bg-green/10 border border-green/25 text-green
                text-[10.5px] font-semibold tracking-[2px] uppercase px-[18px] py-[7px]
                rounded-full mb-8">
      <span class="pdot w-1.5 h-1.5 bg-green rounded-full shrink-0"></span>
      Système de gestion
    </div>

    
    <h1 class="font-extrabold text-[54px] leading-[1.07] text-white tracking-[-2.5px] mb-5 max-w-[700px]
               max-sm:text-[34px] max-sm:tracking-[-1.5px]">
      Gestion des heures<br>
      d'enseignants de
      <span class="text-transparent bg-clip-text"
            style="background-image:linear-gradient(135deg,#00C07F 0%,#00e5c9 100%)">L'UVCI</span>
    </h1>

    
    <p class="text-[15.5px] text-white/60 leading-[1.8] max-w-[480px] mx-auto mb-12 max-sm:text-[14px]">
      Plateforme centralisée permettant la gestion automatisée des heures
      d'enseignement et des activités pédagogiques des enseignants.
    </p>

    
    <button onclick="showLogin()"
            class="inline-flex items-center gap-2.5 bg-green text-navy font-bold text-[15px]
                   px-10 py-[15px] rounded-[14px] border-0 cursor-pointer
                   shadow-[0_0_40px_rgba(0,192,127,.3)]
                   hover:bg-[#00dc96] hover:-translate-y-[3px] hover:shadow-[0_14px_44px_rgba(0,192,127,.5)]
                   active:-translate-y-px transition-all duration-200 group">
      Se connecter
      <svg fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"
           class="w-[17px] h-[17px] transition-transform duration-300 group-hover:translate-x-1.5">
        <path stroke-linecap="round" stroke-linejoin="round" d="M13 7l5 5m0 0l-5 5m5-5H6"/>
      </svg>
    </button>

  </div>

  
  <div id="p2" class="absolute inset-0 flex items-center justify-center p-5 overflow-y-auto">
    <div class="w-full max-w-[420px] relative rounded-3xl px-10 py-11
                max-sm:px-7 max-sm:py-9 max-sm:rounded-[18px]"
         style="background:rgba(255,255,255,0.97);
                box-shadow:0 0 0 1px rgba(255,255,255,.08),0 8px 24px rgba(0,0,0,.18),0 40px 80px rgba(0,0,0,.55);">

      
      <div class="absolute top-0 left-0 right-0 h-[3px] rounded-t-3xl"
           style="background:linear-gradient(90deg,#00C07F 0%,#00d8ff 45%,#FF6B35 100%)"></div>

      
      <button onclick="showAccueil()"
              class="inline-flex items-center gap-1.5 bg-[#F1F4F8] border-0 text-[#6B7A8D]
                     text-[12.5px] cursor-pointer px-3 py-[7px] rounded-lg mb-6 font-[inherit]
                     hover:bg-[#E2E8F0] hover:text-[#0D1B2A] transition-all">
        <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" class="w-[13px] h-[13px]">
          <path stroke-linecap="round" stroke-linejoin="round" d="M11 17l-5-5m0 0l5-5m-5 5h12"/>
        </svg>
        Retour à l'accueil
      </button>

      
      <p class="text-[10.5px] font-bold text-green tracking-[2px] uppercase mb-1.5">Accès sécurisé</p>
      <h2 class="font-extrabold text-[26px] text-[#0D1B2A] tracking-[-0.8px] mb-1 flex items-center gap-2.5">
        Bienvenue
        <svg width="22" height="22" fill="none" stroke="#00C07F" stroke-width="1.8" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round"
                d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z"/>
        </svg>
      </h2>
      <p class="text-[13px] text-[#6B7A8D] mb-6 leading-[1.55]">
        Connectez-vous à votre espace de gestion pédagogique.
      </p>

      
      <?php if($errors->any()): ?>
      <div class="bg-[#FFF0F0] border border-[#FFCDD2] text-[#C62828] rounded-[10px]
                  px-3.5 py-3 mb-4 text-[12.5px] flex items-center gap-2">
        <svg width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" class="shrink-0">
          <circle cx="12" cy="12" r="10"/>
          <line x1="12" y1="8" x2="12" y2="12"/>
          <line x1="12" y1="16" x2="12.01" y2="16"/>
        </svg>
        <?php echo e($errors->first()); ?>

      </div>
      <?php endif; ?>

      <form method="POST" action="<?php echo e(route('login.post')); ?>">
        <?php echo csrf_field(); ?>

        
        <span class="block text-[12.5px] font-bold text-[#0D1B2A] mb-2.5">Je suis…</span>
        <?php $or = old('role','secretaire'); ?>
        <div class="rgrid grid grid-cols-3 gap-2 mb-5">
          <?php $__currentLoopData = [
            ['administrateur',
             '<svg width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/><circle cx="12" cy="12" r="3"/></svg>',
             'Administrateur'],
            ['secretaire',
             '<svg width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4"/></svg>',
             'Secrétaire'],
            ['enseignant',
             '<svg width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"/></svg>',
             'Enseignant'],
          ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$val,$ico,$lbl]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <label class="cursor-pointer block">
            <input type="radio" name="role" value="<?php echo e($val); ?>" <?php echo e($or===$val?'checked':''); ?>>
            <div class="rc flex flex-col items-center pt-3 pb-2.5 px-1
                        border-[1.5px] border-[#E2E8F0] rounded-[14px] bg-[#F8FAFC]
                        relative transition-all duration-200 select-none hover:-translate-y-px">
              <div class="rchk absolute top-1.5 right-1.5 w-3.5 h-3.5 bg-green rounded-full
                          items-center justify-center">
                <svg width="8" height="8" fill="none" stroke="white" stroke-width="3" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/>
                </svg>
              </div>
              <span class="rico flex items-center justify-center mb-1.5 text-[#6B7A8D]"><?php echo $ico; ?></span>
              <span class="rnam text-[10.5px] font-semibold text-[#6B7A8D]"><?php echo e($lbl); ?></span>
            </div>
          </label>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        
        <div class="mb-3.5">
          <label class="block text-[12.5px] font-bold text-[#0D1B2A] mb-1.5">Adresse email</label>
          <div class="relative">
            <svg class="absolute left-3 top-1/2 -translate-y-1/2 w-[15px] h-[15px] text-[#b8c1cc] pointer-events-none"
                 viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
              <polyline points="22,6 12,13 2,6"/>
            </svg>
            <input type="email" name="email" value="<?php echo e(old('email')); ?>"
                   placeholder="votre@uvci.edu.ci"
                   class="w-full pl-10 pr-4 py-3 border-[1.5px] border-[#E2E8F0] rounded-xl
                          text-[13.5px] text-[#0D1B2A] bg-[#F8FAFC] outline-none font-[inherit]
                          placeholder-[#c4ccd6]
                          focus:border-green focus:bg-white focus:shadow-[0_0_0_3.5px_rgba(0,192,127,.13)]
                          transition-all" required>
          </div>
        </div>

        
        <div class="mb-5">
          <label class="block text-[12.5px] font-bold text-[#0D1B2A] mb-1.5">Mot de passe</label>
          <div class="relative">
            <svg class="absolute left-3 top-1/2 -translate-y-1/2 w-[15px] h-[15px] text-[#b8c1cc] pointer-events-none"
                 viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <rect x="3" y="11" width="18" height="11" rx="2"/>
              <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
            </svg>
            <input type="password" id="pwd" name="password" placeholder="••••••••"
                   class="w-full pl-10 pr-10 py-3 border-[1.5px] border-[#E2E8F0] rounded-xl
                          text-[13.5px] text-[#0D1B2A] bg-[#F8FAFC] outline-none font-[inherit]
                          placeholder-[#c4ccd6]
                          focus:border-green focus:bg-white focus:shadow-[0_0_0_3.5px_rgba(0,192,127,.13)]
                          transition-all" required>
            <button type="button" onclick="togglePwd()"
                    class="absolute right-3 top-1/2 -translate-y-1/2 bg-transparent border-0
                           cursor-pointer p-1 text-[#b8c1cc] hover:text-[#6B7A8D] transition-colors">
              <svg id="eyeico" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                <circle cx="12" cy="12" r="3"/>
              </svg>
            </button>
          </div>
        </div>

        
        <div class="mb-5">
          <label class="flex items-center gap-2 text-[12.5px] text-[#6B7A8D] cursor-pointer select-none">
            <input type="checkbox" name="remember" checked class="accent-green w-3.5 h-3.5">
            Se souvenir de moi
          </label>
        </div>

        <button type="submit"
                class="w-full py-3.5 bg-[#0D1B2A] text-white border-0 rounded-[13px] text-[14.5px]
                       font-bold cursor-pointer tracking-[.2px] font-[inherit]
                       hover:bg-[#132233] hover:-translate-y-0.5 hover:shadow-[0_12px_32px_rgba(13,27,42,.35)]
                       active:translate-y-0 active:shadow-none transition-all duration-200">
          Se connecter
        </button>
      </form>

      <p class="text-center mt-4 text-[11.5px] text-[#a0aab4]">
        Accès réservé au personnel autorisé de l'<strong class="text-green-dark">UVCI</strong>
      </p>
    </div>
  </div>

</div>

<script>
function showLogin(){
  document.getElementById('p1').classList.add('out');
  document.getElementById('p2').classList.add('in');
  setTimeout(function(){ var e=document.querySelector('input[name="email"]'); if(e) e.focus(); },620);
}
function showAccueil(){
  document.getElementById('p2').classList.remove('in');
  document.getElementById('p1').classList.remove('out');
}
function togglePwd(){
  var i=document.getElementById('pwd'),s=document.getElementById('eyeico');
  if(i.type==='password'){
    i.type='text';
    s.innerHTML='<path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/>';
  } else {
    i.type='password';
    s.innerHTML='<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>';
  }
}
<?php if($errors->any()): ?>
document.addEventListener('DOMContentLoaded', showLogin);
<?php endif; ?>
</script>
</body>
</html><?php /**PATH C:\Users\HP\uvci-heures\resources\views/auth/login.blade.php ENDPATH**/ ?>