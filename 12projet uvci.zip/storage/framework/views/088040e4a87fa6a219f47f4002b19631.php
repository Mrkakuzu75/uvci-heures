<?php $__env->startSection('title','Mes activités'); ?>
<?php $__env->startSection('sidebar-role','Enseignant'); ?>
<?php $__env->startSection('page-title','Mes activités'); ?>
<?php $__env->startSection('page-subtitle','Historique de vos activités pédagogiques'); ?>

<?php $__env->startSection('sidebar-nav'); ?>
  <?php if (isset($component)) { $__componentOriginal6cced52613a484e7295a90162a92d81b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6cced52613a484e7295a90162a92d81b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.nav-item','data' => ['route' => 'enseignant.dashboard','label' => 'Tableau de bord','icon' => 'M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('nav-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['route' => 'enseignant.dashboard','label' => 'Tableau de bord','icon' => 'M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6cced52613a484e7295a90162a92d81b)): ?>
<?php $attributes = $__attributesOriginal6cced52613a484e7295a90162a92d81b; ?>
<?php unset($__attributesOriginal6cced52613a484e7295a90162a92d81b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6cced52613a484e7295a90162a92d81b)): ?>
<?php $component = $__componentOriginal6cced52613a484e7295a90162a92d81b; ?>
<?php unset($__componentOriginal6cced52613a484e7295a90162a92d81b); ?>
<?php endif; ?>
  <?php if (isset($component)) { $__componentOriginal6cced52613a484e7295a90162a92d81b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6cced52613a484e7295a90162a92d81b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.nav-item','data' => ['route' => 'enseignant.activites','label' => 'Mes activités','icon' => 'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('nav-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['route' => 'enseignant.activites','label' => 'Mes activités','icon' => 'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6cced52613a484e7295a90162a92d81b)): ?>
<?php $attributes = $__attributesOriginal6cced52613a484e7295a90162a92d81b; ?>
<?php unset($__attributesOriginal6cced52613a484e7295a90162a92d81b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6cced52613a484e7295a90162a92d81b)): ?>
<?php $component = $__componentOriginal6cced52613a484e7295a90162a92d81b; ?>
<?php unset($__componentOriginal6cced52613a484e7295a90162a92d81b); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('topbar-actions'); ?>
  <form method="GET" action="<?php echo e(route('enseignant.activites')); ?>" class="flex items-center gap-2">
    <select name="annee_id" onchange="this.form.submit()" class="form-input py-1.5 text-[13px] w-auto">
      <?php $__currentLoopData = $annees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($a->id_anee); ?>" <?php echo e($anneeId==$a->id_anee?'selected':''); ?>>
        <?php echo e($a->lib_anee); ?><?php echo e($a->etat_anee==='en_cours'?' ✓':''); ?>

      </option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
  </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<div class="kpi-grid mb-5">
  <div class="kpi-card">
    <div class="kpi-icon" style="color:#00C07F;">
      <svg width="28" height="28" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24">
        <circle cx="12" cy="12" r="9"/>
        <path stroke-linecap="round" stroke-linejoin="round" d="M12 7v5l3.5 3.5"/>
      </svg>
    </div>
    <div class="kpi-value"><?php echo e(number_format($volumeTotal,1)); ?>h</div>
    <div class="kpi-label">Volume horaire total</div>
    <div class="kpi-bar"><div class="kpi-fill" style="background:#00C07F;width:70%"></div></div>
  </div>
  <div class="kpi-card">
    <div class="kpi-icon" style="color:#4A90E2;">
      <svg width="28" height="28" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4"/>
      </svg>
    </div>
    <div class="kpi-value"><?php echo e($activites->total()); ?></div>
    <div class="kpi-label">Activités enregistrées</div>
    <div class="kpi-bar"><div class="kpi-fill" style="background:#4A90E2;width:60%"></div></div>
  </div>
  <div class="kpi-card">
    <div class="kpi-icon" style="color:#9B59B6;">
      <svg width="28" height="28" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
      </svg>
    </div>
    <div class="kpi-value"><?php echo e(number_format($volumeTotal * $enseignant->tx_horaire, 0)); ?></div>
    <div class="kpi-label">Estimation FCFA</div>
    <div class="kpi-bar"><div class="kpi-fill" style="background:#9B59B6;width:50%"></div></div>
  </div>
</div>


<div class="card">
  <div class="card-header">
    <h3>Détail des activités</h3>
    <span class="text-[13px] font-semibold text-green">Total : <?php echo e(number_format($volumeTotal,1)); ?>h</span>
  </div>
  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>Date</th>
          <th>Cours</th>
          <th>Séquence</th>
          <th class="hide-mobile">Type</th>
          <th class="hide-mobile">Niv.</th>
          <th>Volume</th>
          <th>Statut</th>
        </tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $activites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $act): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
          <td class="text-[#6B7A8D] whitespace-nowrap text-[13px]"><?php echo e($act->date_act->format('d/m/Y')); ?></td>
          <td>
            <div class="font-medium text-[13px] max-w-[160px] truncate">
              <?php echo e($act->ressource?->sequence?->cours?->intit ?? '—'); ?>

            </div>
          </td>
          <td class="text-[12px] text-[#6B7A8D] max-w-[140px] truncate">
            <?php echo e($act->ressource?->sequence?->ttre_seq ?? '—'); ?>

          </td>
          <td class="hide-mobile">
            <?php if($act->id_typ_act==1): ?>
              <span class="badge-green">Création</span>
            <?php else: ?>
              <span class="badge-orange">Mise à jour</span>
            <?php endif; ?>
          </td>
          <td class="hide-mobile">
            <span class="inline-flex w-7 h-7 rounded-lg bg-[#F4F6FA] items-center justify-center font-bold text-[13px]">
              N<?php echo e($act->ressource?->niv_comp ?? '?'); ?>

            </span>
          </td>
          <td class="font-bold text-[14px] text-green whitespace-nowrap"><?php echo e(number_format($act->v_hor,2)); ?>h</td>
          <td>
            <?php if($act->est_valide): ?>
              <span class="badge-green">Validée</span>
              <?php if($act->date_validation): ?>
              <div class="text-[10px] text-[#6B7A8D] mt-0.5">le <?php echo e($act->date_validation->format('d/m/Y')); ?></div>
              <?php endif; ?>
            <?php else: ?>
              <span class="inline-block px-2.5 py-1 rounded-full text-[11px] font-semibold
                           bg-red-50 border border-red-200 text-red-600">En attente</span>
            <?php endif; ?>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
          <td colspan="7" class="text-center py-10 text-[#6B7A8D]">Aucune activité pour cette période</td>
        </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php if($activites->hasPages()): ?>
  <div class="px-5 py-3.5 border-t border-[#E2E8F0]"><?php echo e($activites->links()); ?></div>
  <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\HP\uvci-heures\resources\views/enseignant/activites.blade.php ENDPATH**/ ?>