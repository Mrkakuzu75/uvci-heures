<?php $__env->startSection('title','Mon espace'); ?>
<?php $__env->startSection('sidebar-role','Enseignant'); ?>
<?php $__env->startSection('page-title','Mon espace pédagogique'); ?>
<?php $__env->startSection('page-subtitle','Consultez vos activités et volumes horaires'); ?>

<?php $__env->startSection('sidebar-nav'); ?>
  <?php if (isset($component)) { $__componentOriginal6cced52613a484e7295a90162a92d81b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6cced52613a484e7295a90162a92d81b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.nav-item','data' => ['route' => 'enseignant.dashboard','label' => 'Tableau de bord','icon' => 'M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('nav-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['route' => 'enseignant.dashboard','label' => 'Tableau de bord','icon' => 'M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6cced52613a484e7295a90162a92d81b)): ?>
<?php $attributes = $__attributesOriginal6cced52613a484e7295a90162a92d81b; ?>
<?php unset($__attributesOriginal6cced52613a484e7295a90162a92d81b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6cced52613a484e7295a90162a92d81b)): ?>
<?php $component = $__componentOriginal6cced52613a484e7295a90162a92d81b; ?>
<?php unset($__componentOriginal6cced52613a484e7295a90162a92d81b); ?>
<?php endif; ?>
  <?php if (isset($component)) { $__componentOriginal6cced52613a484e7295a90162a92d81b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6cced52613a484e7295a90162a92d81b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.nav-item','data' => ['route' => 'enseignant.activites','label' => 'Mes activités','icon' => 'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('nav-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['route' => 'enseignant.activites','label' => 'Mes activités','icon' => 'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6cced52613a484e7295a90162a92d81b)): ?>
<?php $attributes = $__attributesOriginal6cced52613a484e7295a90162a92d81b; ?>
<?php unset($__attributesOriginal6cced52613a484e7295a90162a92d81b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6cced52613a484e7295a90162a92d81b)): ?>
<?php $component = $__componentOriginal6cced52613a484e7295a90162a92d81b; ?>
<?php unset($__componentOriginal6cced52613a484e7295a90162a92d81b); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<div class="relative rounded-2xl overflow-hidden mb-5 p-7"
     style="background:linear-gradient(135deg,#0D1B2A 0%,#1A3A5C 100%)">
  
  <div class="absolute -top-10 -right-10 w-48 h-48 rounded-full bg-green opacity-[.06]"></div>

  <div class="relative flex flex-wrap items-center justify-between gap-5">
    
    <div class="flex items-center gap-4">
      <div class="w-[60px] h-[60px] rounded-2xl bg-green flex items-center justify-center
                  font-extrabold text-[22px] text-navy border-[3px] border-white/15 shrink-0">
        <?php echo e($enseignant->initiales); ?>

      </div>
      <div>
        <div class="font-bold text-[20px] text-white mb-1.5"><?php echo e($enseignant->nom_complet); ?></div>
        <div class="flex flex-wrap gap-1.5">
          <span class="bg-white/10 text-white/75 text-[12px] px-2.5 py-0.5 rounded-full">
            <?php echo e($enseignant->grade?->lib_grd); ?>

          </span>
          <span class="bg-white/10 text-white/75 text-[12px] px-2.5 py-0.5 rounded-full">
            <?php echo e($enseignant->departement?->lib_dep); ?>

          </span>
          <?php if(strtolower($enseignant->statut?->lib_stat??'') === 'permanent'): ?>
          <span class="bg-green/20 text-green text-[12px] px-2.5 py-0.5 rounded-full">Permanent</span>
          <?php else: ?>
          <span class="bg-orange/20 text-orange text-[12px] px-2.5 py-0.5 rounded-full">Vacataire</span>
          <?php endif; ?>
        </div>
      </div>
    </div>

    
    <div class="flex gap-2 flex-wrap">
      <a href="<?php echo e(route('enseignant.activites')); ?>"
         class="btn bg-white/10 text-white border border-white/20 hover:bg-white/20">
        Mes activités →
      </a>
      <a href="<?php echo e(route('enseignant.recapitulatif', ['annee_id'=>$annee?->id_anee])); ?>"
         target="_blank"
         class="btn bg-green text-navy font-semibold hover:bg-green-dark">
        <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" class="shrink-0">
          <path stroke-linecap="round" stroke-linejoin="round" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"/>
        </svg>
        Télécharger récapitulatif
      </a>
    </div>
  </div>

  
  <div class="relative grid gap-0 mt-6 pt-5 border-t border-white/10"
       style="grid-template-columns:repeat(auto-fit,minmax(120px,1fr))">
    <div class="pr-5">
      <div class="text-[11px] text-white/40 uppercase tracking-[.8px] mb-1">Volume total</div>
      <div class="font-bold text-[24px] text-white">
        <?php echo e(number_format($volumeTotal,1)); ?><span class="text-[13px] font-normal text-white/50 ml-1">h</span>
      </div>
    </div>
    <div class="px-5 border-l border-white/10">
      <div class="text-[11px] text-white/40 uppercase tracking-[.8px] mb-1">H. complémentaires</div>
      <div class="font-bold text-[24px] <?php echo e($heuresComplementaires > 0 ? 'text-orange' : 'text-white'); ?>">
        <?php echo e(number_format($heuresComplementaires,1)); ?><span class="text-[13px] font-normal text-white/50 ml-1">h</span>
      </div>
    </div>
    <div class="px-5 border-l border-white/10">
      <div class="text-[11px] text-white/40 uppercase tracking-[.8px] mb-1">Activités</div>
      <div class="font-bold text-[24px] text-[#5BA4F5]"><?php echo e($activites->count()); ?></div>
    </div>
    <div class="pl-5 border-l border-white/10">
      <div class="text-[11px] text-white/40 uppercase tracking-[.8px] mb-1">Taux horaire</div>
      <div class="font-bold text-[24px] text-white">
        <?php echo e(number_format($enseignant->tx_horaire,0)); ?><span class="text-[11px] font-normal text-white/50 ml-1">FCFA/h</span>
      </div>
    </div>
  </div>
</div>


<div class="card">
  <div class="card-header">
    <h3>Activités récentes</h3>
    <a href="<?php echo e(route('enseignant.activites')); ?>" class="text-[12px] font-medium text-green-dark no-underline hover:underline">
      Tout voir →
    </a>
  </div>
  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>Date</th>
          <th>Cours / Ressource</th>
          <th class="hide-mobile">Type</th>
          <th class="hide-mobile">Niveau</th>
          <th>Volume (h)</th>
        </tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $activites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $act): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
          <td class="text-[#6B7A8D] whitespace-nowrap"><?php echo e($act->date_act->format('d/m/Y')); ?></td>
          <td>
            <div class="text-[13.5px] font-medium"><?php echo e($act->ressource?->sequence?->cours?->intit ?? '—'); ?></div>
            <div class="text-[11px] text-[#6B7A8D]"><?php echo e($act->ressource?->sequence?->ttre_seq ?? ''); ?></div>
          </td>
          <td class="hide-mobile">
            <?php if($act->id_typ_act == 1): ?>
              <span class="badge-green">Création</span>
            <?php else: ?>
              <span class="badge-orange">Mise à jour</span>
            <?php endif; ?>
          </td>
          <td class="hide-mobile">
            <span class="inline-flex w-7 h-7 rounded-lg bg-[#F4F6FA] items-center justify-center font-bold text-[13px]">
              N<?php echo e($act->ressource?->niv_comp ?? '?'); ?>

            </span>
          </td>
          <td class="font-bold text-[14px] text-green"><?php echo e(number_format($act->v_hor,2)); ?>h</td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
          <td colspan="5" class="text-center py-10 text-[#6B7A8D]">Aucune activité enregistrée</td>
        </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\HP\uvci-heures\resources\views/enseignant/dashboard.blade.php ENDPATH**/ ?>